"""Score the existing M0/M2 checkpoints once; keep all previous artifacts intact.

Run from the project root with code/solution/.venv/bin/python and one parent thread.
No training, tuning, or model selection is performed.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import tarfile
import time
import zipfile

ROOT = Path.cwd()
CODE = ROOT / "code"
RUNS = CODE / "solution/runs"
sys.path.insert(0, str(CODE))

import numpy as np
from common import DATA, PROTOCOL, check_data, load_inputs, parse_answer, read_jsonl, validate_choices
from solution.evaluate import THREAD_VARIABLES, accuracy, bootstrap_interval, confidence_summary, run_official
from solution.group_ranker.evidence import arithmetic_counts
from solution.group_ranker.features import answer_groups
from solution.group_ranker.submission_mlp import predict_profiled


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def now():
    return datetime.now(timezone.utc).isoformat()


def comparison(correct, reference):
    difference = correct.astype(int) - reference.astype(int)
    return {"corrected": int(np.sum(correct & ~reference)),
            "regressed": int(np.sum(~correct & reference)),
            "net_correct": int(difference.sum()), "difference_pp": float(100 * difference.mean()),
            "paired_bootstrap_95ci_pp": bootstrap_interval(difference),
            "bootstrap_draws": 2000, "bootstrap_seed": 7506,
            "multiple_comparison_adjustment": False}


policy = ("既有 test 已接触；此次仅补充评分历史固定 M0/M2，属于事后冻结评分，不称新盲测。"
          "不训练、不调参、不更换种子、不添加规则或融合，不据 test 改变 validation 选定的最终融合。")
models = {"m0": "mlp_v1", "m2": "mlp_arithmetic_v1"}
for run in models.values():
    if (RUNS / run / "test").exists():
        raise FileExistsError(f"Refuse to overwrite {run}/test")
historical = {path: sha(path) for path in RUNS.rglob("*") if path.is_file()}
source = sorted({CODE / name for name in ("common.py", "predict.py", "score_predictions.py",
    "check_data.py", "requirements.txt", "PACKAGE_MANIFEST.json", "solution/__init__.py",
    "solution/evaluate.py", "solution/requirements-train.txt")}
    | set((CODE / "solution/group_ranker").glob("*.py")) | {ROOT / "guide/GUIDE.md"})
checkpoints, records, manifests = {}, {}, {}

# Freeze both models before either test score is opened.
for name, run in models.items():
    checkpoint, output = RUNS / run / "checkpoint", RUNS / run / "test"
    output.mkdir()
    checkpoints[name] = checkpoint
    assets = sorted(path for path in checkpoint.rglob("*") if path.is_file())
    with zipfile.ZipFile(checkpoint / "model.npz") as archive:
        assert all(item.compress_type == zipfile.ZIP_STORED for item in archive.infolist())
    frozen = source + assets + [RUNS / run / suffix for suffix in (
        "training.json", "oof.npz", "source.tar", "validation/summary.json")]
    with tarfile.open(output / "source.tar", "w") as archive:
        for path in source:
            archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
        archive.add(Path(__file__), arcname="test_driver.py", recursive=False)
    manifest = {"created_utc": now(), "protocol": PROTOCOL,
        "method": "solution/group_ranker/submission_mlp.py",
        "checkpoint": str(checkpoint.relative_to(CODE)), "config": read(checkpoint / "config.json"),
        "sha256": {str(path.relative_to(ROOT)): sha(path) for path in frozen},
        "data_manifest_sha256": sha(DATA / "manifest.json"),
        "validation_replay": {"all_798_choices_match_historical": True,
                              "performed_before_test": True},
        "selection_basis": "原 train OOF 选定的历史 checkpoint；M0/M2 均重训 4 轮，最终种子 7506。",
        "test_policy": policy,
        "inference_assets": {"bytes": sum(path.stat().st_size for path in assets),
                             "limit_bytes": 16 * 2**20, "all_npz_uncompressed": True},
        "source_archive": {"file": "source.tar", "sha256": sha(output / "source.tar")}}
    manifest["freeze_id"] = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode()).hexdigest()
    write(output / "freeze.json", manifest)
    manifests[name] = manifest

child_env = {**os.environ, **dict.fromkeys(THREAD_VARIABLES, "3")}
child_env.pop("PYTHONPATH", None)
cpu = next(line.split(":", 1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines()
           if line.startswith("model name"))
for name, run in models.items():
    output = RUNS / run / "test"
    relative = output.relative_to(CODE)
    prediction = [sys.executable, "predict.py", "--method", "solution/group_ranker/submission_mlp.py",
        "--checkpoint", str(checkpoints[name].relative_to(CODE)), "--split", "test",
        "--output", str(relative / "predictions.json")]
    scoring = [sys.executable, "score_predictions.py", "--split", "test",
        "--predictions", str(relative / "predictions.json"), "--output", str(relative / "score.json")]
    started, tick = now(), time.perf_counter()
    processes = [run_official(prediction, child_env)]
    write(output / "prediction_freeze.json", {"created_utc": now(),
        "freeze_id": manifests[name]["freeze_id"], "predictions_sha256": sha(output / "predictions.json")})
    processes.append(run_official(scoring, child_env))
    elapsed = time.perf_counter() - tick
    records[name] = {"freeze_id": manifests[name]["freeze_id"],
        "freeze_manifest_sha256": sha(output / "freeze.json"), "started_utc": started,
        "finished_utc": now(), "split": "test", "method": manifests[name]["method"],
        "official": read(output / "score.json"), "total_wall_seconds": elapsed,
        "processes": processes, "inference_asset_bytes": manifests[name]["inference_assets"]["bytes"],
        "environment": {"python": platform.python_version(), "numpy": np.__version__,
            "python_executable": sys.executable, "cpu": cpu, "platform": platform.platform(),
            "pythonpath_removed": True, "thread_budget_total": 4, "coordinator_threads": 1,
            "child_threads": 3, "child_thread_environment": dict.fromkeys(THREAD_VARIABLES, "3")},
        "measurement": "两个顺序新进程的外部计时，含启动、导入、哈希检查、载入、预处理、前向、输出、预测冻结与独立评分；缓存未控制。",
        "scope": policy, "complete_test_bank": True,
        "eligibility": {"local_under_30_seconds": elapsed <= 30,
            "observed_total_threads_at_most_4": max(p["total_peak_threads"] for p in processes) <= 4,
            "assets_within_16_mib": manifests[name]["inference_assets"]["bytes"] <= 16 * 2**20,
            "reference_cpu_verified": False},
        "artifact_sha256": {file: sha(output / file) for file in (
            "predictions.json", "score.json", "prediction_freeze.json")}}
    write(output / "summary.json", records[name])
    print(json.dumps({"method": name, "official": records[name]["official"],
                      "wall_seconds": elapsed}, ensure_ascii=False), flush=True)

# References are opened only after official predictions and independent scores are saved.
check_data(DATA, ("test",))
bank, arrays = load_inputs("test")
gold = read_jsonl(DATA / "gsm8k_test.jsonl")
assert [(r["id"], r["question"]) for r in bank] == [(r["id"], r["question"]) for r in gold]
answers = [parse_answer(row["answer"]) for row in gold]
groups = [answer_groups(row["candidates"]) for row in bank]
counts = np.array([len(group) for group in groups])
patterns = np.array(["+".join(map(str, sorted(map(len, group.values()), reverse=True))) for group in groups])
paths = {name: (RUNS / run / "test/predictions.json", RUNS / run / "test/score.json")
         for name, run in {**models, "linear": "linear_v1", "m1": "mlp_text_v1", "ensemble": "ensemble_v1"}.items()}
paths["baseline"] = (RUNS / "baselines/final-test-predictions.json", RUNS / "baselines/final-test-score.json")
correctness = {}
for name, (prediction_path, score_path) in paths.items():
    predictions = read(prediction_path)
    validate_choices(bank, predictions["ids"], predictions["selected"])
    correct = np.array([parse_answer(row["candidates"][j]["text"]) == answer
                       for row, j, answer in zip(bank, predictions["selected"], answers)])
    assert int(correct.sum()) == read(score_path)["correct"]
    correctness[name] = correct
covered = np.array([any(sum(arithmetic_counts(row["candidates"][j]["text"])[:2])
                          for indices in group.values() for j in indices)
                    for row, group in zip(bank, groups)])
for name, run in models.items():
    output, record = RUNS / run / "test", records[name]
    choices, profile = predict_profiled(bank, arrays, checkpoints[name], include_scores=True)
    assert choices == read(output / "predictions.json")["selected"]
    scores = profile.pop("group_scores")
    correct = correctness[name]
    analysis = {"purpose": policy, "correct": int(correct.sum()), "wrong": int((~correct).sum()),
        "by_group_count": {str(g): accuracy(correct[counts == g]) for g in sorted(set(counts))},
        "by_vote_pattern": {p: accuracy(correct[patterns == p]) for p in sorted(set(patterns))},
        "profile_replay": profile,
        "confidence": confidence_summary(scores, groups, answers, correct, counts >= 2)}
    for other, reference in correctness.items():
        if other != name:
            analysis["vs_" + other] = {**comparison(correct, reference),
                "official": read(paths[other][1]), "predictions_sha256": sha(paths[other][0])}
    analysis["by_arithmetic_coverage"] = {
        label: {"own": accuracy(correct[mask]), "m1": accuracy(correctness["m1"][mask]),
                "vs_m1": comparison(correct[mask], correctness["m1"][mask])}
        for label, mask in (("covered", covered), ("not_covered", ~covered))}
    record["analysis"] = analysis
    record["frozen_files_unchanged"] = all(sha(ROOT / p) == digest for p, digest in manifests[name]["sha256"].items())
    record["historical_artifact_count"] = len(historical)
    record["historical_artifacts_unchanged"] = all(sha(p) == digest for p, digest in historical.items())
    assert record["frozen_files_unchanged"] and record["historical_artifacts_unchanged"]
    assert sha(output / "predictions.json") == read(output / "prediction_freeze.json")["predictions_sha256"]
    write(output / "summary.json", record)
    print(json.dumps({"method": name,
        "by_group_count": analysis["by_group_count"], "vs_linear": analysis["vs_linear"],
        "vs_m1": analysis["vs_m1"], "vs_ensemble": analysis["vs_ensemble"],
        "by_arithmetic_coverage": analysis["by_arithmetic_coverage"],
        "profile": profile, "resources": record["eligibility"]}, ensure_ascii=False), flush=True)
