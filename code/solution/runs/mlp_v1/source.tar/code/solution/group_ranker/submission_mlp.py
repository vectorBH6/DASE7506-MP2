"""M0 官方预测接口：同一套基础特征，冻结 MLP，纯 NumPy 推理。"""
import hashlib
import json
from pathlib import Path

import numpy as np

from solution.group_ranker.features import (
    EMBED_DIM, FEATURE_DIM, FEATURE_VERSION, answer_groups, best_group, build_features, standardize,
)
from solution.group_ranker.mlp import PARAMETERS, forward


def load_model(checkpoint):
    if checkpoint is None:
        raise ValueError("请指定 MLP checkpoint")
    directory = Path(checkpoint)
    manifest = json.loads((directory / "asset_manifest.json").read_text(encoding="utf-8"))
    for name in ("config.json", "model.npz"):
        if hashlib.sha256((directory / name).read_bytes()).hexdigest() != manifest["sha256"][name]:
            raise ValueError(f"推理资产哈希不符：{name}")
    config = json.loads((directory / "config.json").read_text(encoding="utf-8"))
    if (config.get("model") != "mlp" or config.get("feature_version") != FEATURE_VERSION
            or config.get("feature_dim") != FEATURE_DIM or config.get("hidden") not in ([64, 16], [32, 16])):
        raise ValueError("MLP checkpoint 结构或特征版本错误")
    h1, h2 = config["hidden"]
    shapes = {"w1": (FEATURE_DIM, h1), "b1": (h1,), "w2": (h1, h2), "b2": (h2,),
              "w3": (h2, 1), "b3": (1,), "mean": (FEATURE_DIM,),
              "scale": (FEATURE_DIM,), "active": (FEATURE_DIM,)}
    with np.load(directory / "model.npz", allow_pickle=False) as archive:
        model = {name: archive[name].copy() for name in (*PARAMETERS, "mean", "scale", "active")}
    if any(model[name].shape != shape or not np.isfinite(model[name]).all() for name, shape in shapes.items()):
        raise ValueError("MLP 数组形状或数值错误")
    if np.any(model["scale"] <= 0) or model["active"].dtype != np.bool_:
        raise ValueError("MLP 标准化参数错误")
    return model


def predict(bank, arrays, checkpoint):
    embeddings = np.asarray(arrays["embeddings"])
    if embeddings.shape != (len(bank), 4, EMBED_DIM) or not np.isfinite(embeddings).all():
        raise ValueError("bank 与 embedding 的数量、形状或数值不符合协议")
    if not bank:
        return []
    model = load_model(checkpoint)
    choices = [0] * len(bank)
    for start in range(0, len(bank), 128):
        pending, features = [], []
        for i in range(start, min(start + 128, len(bank))):
            candidates = bank[i]["candidates"]
            if len(candidates) != 4:
                raise ValueError("每题必须有四个候选")
            groups = answer_groups(candidates)
            if len(groups) == 1:
                choices[i] = int(min(next(iter(groups.values()))))
            elif groups:
                pending.append((i, groups))
                features.append(build_features(candidates, embeddings[i], groups))
        if pending:
            x = standardize(np.concatenate(features), model["mean"], model["scale"], model["active"])
            scores, _ = forward(x, model)
            offset = 0
            for i, groups in pending:
                winner = int(best_group(scores[offset:offset + len(groups)]))
                choices[i] = int(min(list(groups.values())[winner]))
                offset += len(groups)
    return choices
