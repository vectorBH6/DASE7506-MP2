"""Validate and freeze the finite capacity comparison before scoring test.

Run from the project root with code/solution/.venv/bin/python.
All experiment artifacts stay under solution/runs/mlp_capacity_v1/.
"""
from datetime import datetime, timezone
import hashlib
from importlib import import_module
import itertools
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tarfile
import time

ROOT = Path.cwd()
CODE = ROOT / "code"
RUNS = CODE / "solution/runs"
OUT = RUNS / "mlp_capacity_v1"
sys.path.insert(0, str(CODE))

import numpy as np
from common import DATA, PROTOCOL, check_data, load_inputs, parse_answer, read_jsonl, validate_choices
from solution.evaluate import THREAD_VARIABLES, accuracy, bootstrap_interval, confidence_summary, run_official
from solution.group_ranker.features import answer_groups


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def now():
    return datetime.now(timezone.utc).isoformat()


def comparison(correct, reference):
    difference = correct.astype(int) - reference.astype(int)
    return {"corrected": int(np.sum(correct & ~reference)),
        "regressed": int(np.sum(~correct & reference)), "net_correct": int(difference.sum()),
        "difference_pp": float(100 * difference.mean()),
        "paired_bootstrap_95ci_pp": bootstrap_interval(difference),
        "bootstrap_draws": 2000, "bootstrap_seed": 7506, "multiple_comparison_adjustment": False}


specs = {f"{kind}_{width}": (kind, width) for width in (128, 256) for kind in ("m1", "ensemble")}
modules = {kind: import_module("solution.group_ranker.submission_" + suffix)
           for kind, suffix in (("m1", "mlp"), ("ensemble", "ensemble"))}
plan = read(OUT / "plan.json")
historical = read(OUT / "historical_sha256.json")
assert all(sha(ROOT / path) == digest for path, digest in historical.items())
for name in specs:
    assert not (OUT / name / "test").exists(), "Refuse to overwrite a previous score"

# Unit checks and current checkpoints are checked without test inputs/references.
check_command = [sys.executable, "-m", "unittest", "solution.group_ranker.test_group_ranker",
                 "solution.group_ranker.test_ensemble", "-v"]
result = subprocess.run(check_command, cwd=CODE, env=os.environ, text=True, capture_output=True, check=True)
checks = {"created_utc": now(), "unit_command": check_command, "unit_returncode": result.returncode,
          "unit_stdout": result.stdout, "unit_stderr": result.stderr, "models": {}, "legacy_validation": {}}
bank, arrays = load_inputs("validation")
sample_index = next(i for i, row in enumerate(bank) if len(answer_groups(row["candidates"])) > 1)
row, embedding = bank[sample_index], arrays["embeddings"][sample_index]
selection_candidates = {}
for name, (kind, width) in specs.items():
    module = modules[kind]
    checkpoint = OUT / name / "checkpoint"
    selection_record = read(OUT / f"validation_{width}/summary.json")["methods"][kind]
    saved = read(OUT / f"validation_{width}/{kind}-predictions.json")
    choices = module.predict(bank, arrays, checkpoint)
    assert choices == saved["selected"]
    chosen = choices[sample_index]
    answer = parse_answer(row["candidates"][chosen]["text"])
    for order in itertools.permutations(range(4)):
        reordered = {**row, "candidates": [row["candidates"][j] for j in order]}
        j = module.predict([reordered], {"embeddings": embedding[list(order)][None]}, checkpoint)[0]
        assert parse_answer(reordered["candidates"][j]["text"]) == answer
    repeated = module.predict([row] * 129, {"embeddings": np.tile(embedding, (129, 1, 1))}, checkpoint)
    assert repeated == [chosen] * 129
    with np.load(RUNS / "linear_v1/oof.npz", allow_pickle=False) as base, np.load(OUT / name / "oof.npz", allow_pickle=False) as own:
        assert np.array_equal(own["labels"], base["labels"])
        assert np.array_equal(own["folds"], base["folds"])
    checks["models"][name] = {"validation_replay_identical": True, "all_24_permutations": True,
                              "cross_chunk_129": True, "oof_labels_and_folds_identical": True}
    selection_candidates[name] = {key: selection_record[key] for key in (
        "official", "enabled_input_dimensions", "inference_asset_bytes", "total_wall_seconds")}
for kind, directory, key in (("m1", "mlp_text_v1", "m1"), ("ensemble", "ensemble_v1", "ensemble")):
    checkpoint = RUNS / directory / "checkpoint"
    previous = read(RUNS / ("p3" if kind == "m1" else directory) / "validation" / f"{key}-predictions.json")
    assert modules[kind].predict(bank, arrays, checkpoint) == previous["selected"]
    checks["legacy_validation"][directory] = {"all_798_choices_identical": True}
legacy = read(RUNS / "ensemble_v1/validation/summary.json")["methods"]["ensemble"]
selection_candidates["ensemble_v1"] = {key: legacy[key] for key in (
    "official", "enabled_input_dimensions", "inference_asset_bytes", "total_wall_seconds")}
eligible = [name for name, r in selection_candidates.items()
            if r["inference_asset_bytes"] <= 16 * 2**20 and r["total_wall_seconds"] <= 30]
selected = min(eligible, key=lambda name: (-selection_candidates[name]["official"]["accuracy"],
    selection_candidates[name]["enabled_input_dimensions"], selection_candidates[name]["inference_asset_bytes"],
    selection_candidates[name]["total_wall_seconds"], name))
selection = {"created_utc": now(), "selected": selected, "rule": plan["selection_rule"],
             "candidates": selection_candidates, "all_new_test_scores_not_yet_run": True,
             "scope": "按 validation 锁定本轮选择；历史 test 已见，不称新盲测。"}
write(OUT / "checks.json", checks)
write(OUT / "validation_selection.json", selection)

# Keep one shared source archive for the four model freezes.
source = sorted({CODE / name for name in ("common.py", "predict.py", "score_predictions.py", "check_data.py",
    "requirements.txt", "PACKAGE_MANIFEST.json", "solution/__init__.py", "solution/evaluate.py", "solution/requirements-train.txt")}
    | set((CODE / "solution/group_ranker").glob("*.py")) | {ROOT / "guide/GUIDE.md"})
with tarfile.open(OUT / "source.tar", "w") as archive:
    for path in source:
        archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
    archive.add(Path(__file__), arcname="capacity_evaluation.py", recursive=False)
common_frozen = source + [OUT / file for file in (
    "source.tar", "plan.json", "historical_sha256.json", "checks.json", "validation_selection.json",
    "validation_128/summary.json", "validation_256/summary.json")]
common_hashes = {str(path.relative_to(ROOT)): sha(path) for path in common_frozen}
freezes = {}
for name in specs:
    directory, checkpoint = OUT / name, OUT / name / "checkpoint"
    output = directory / "test"
    output.mkdir()
    files = sorted(p for p in checkpoint.rglob("*") if p.is_file()) + [directory / "oof.npz"]
    files += [directory / ("training.json" if name.startswith("m1") else "preparation.json")]
    freeze = {"created_utc": now(), "protocol": PROTOCOL,
        "config": read(checkpoint / "config.json"), "checkpoint": str(checkpoint.relative_to(CODE)),
        "source_archive": "../../source.tar", "sha256": {**common_hashes,
            **{str(path.relative_to(ROOT)): sha(path) for path in files}},
        "test_policy": plan["test_policy"], "validation_selection": selected,
        "inference_asset_bytes": sum(p.stat().st_size for p in checkpoint.rglob("*") if p.is_file())}
    freeze["freeze_id"] = hashlib.sha256(json.dumps(freeze, sort_keys=True).encode()).hexdigest()
    write(output / "freeze.json", freeze)
    freezes[name] = freeze
print(json.dumps({"validation_selected": selected, "all_four_frozen": True}), flush=True)

child_env = {**os.environ, **dict.fromkeys(THREAD_VARIABLES, "3")}
child_env.pop("PYTHONPATH", None)
cpu = next(line.split(":", 1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines() if line.startswith("model name"))
records = {}
for name, (kind, width) in specs.items():
    output, checkpoint = OUT / name / "test", OUT / name / "checkpoint"
    method = "solution/group_ranker/submission_" + ("mlp.py" if kind == "m1" else "ensemble.py")
    predict = [sys.executable, "predict.py", "--method", method,
               "--checkpoint", str(checkpoint.relative_to(CODE)), "--split", "test",
               "--output", str((output / "predictions.json").relative_to(CODE))]
    score = [sys.executable, "score_predictions.py", "--split", "test",
             "--predictions", str((output / "predictions.json").relative_to(CODE)),
             "--output", str((output / "score.json").relative_to(CODE))]
    started, tick = now(), time.perf_counter()
    processes = [run_official(predict, child_env)]
    write(output / "prediction_freeze.json", {"created_utc": now(), "freeze_id": freezes[name]["freeze_id"],
        "predictions_sha256": sha(output / "predictions.json")})
    processes.append(run_official(score, child_env))
    elapsed = time.perf_counter() - tick
    records[name] = {"created_utc": now(), "started_utc": started, "split": "test",
        "official": read(output / "score.json"), "method": method, "total_wall_seconds": elapsed,
        "freeze_id": freezes[name]["freeze_id"], "freeze_manifest_sha256": sha(output / "freeze.json"),
        "processes": processes, "inference_asset_bytes": freezes[name]["inference_asset_bytes"],
        "environment": {"python": platform.python_version(), "numpy": np.__version__, "cpu": cpu,
            "platform": platform.platform(), "python_executable": sys.executable, "pythonpath_removed": True,
            "coordinator_threads": 1, "child_threads": 3, "thread_budget_total": 4},
        "measurement": "一个新预测进程加独立评分进程；外部计时含启动、导入、加载、预处理、全部成员、输出和预测冻结；缓存未控制。",
        "eligibility": {"local_under_30_seconds": elapsed <= 30,
            "observed_total_threads_at_most_4": max(p["total_peak_threads"] for p in processes) <= 4,
            "assets_within_16_mib": freezes[name]["inference_asset_bytes"] <= 16 * 2**20,
            "reference_cpu_verified": False}, "complete_test_bank": True, "scope": plan["test_policy"],
        "artifact_sha256": {file: sha(output / file) for file in ("predictions.json", "score.json", "prediction_freeze.json")}}
    write(output / "summary.json", records[name])
    print(json.dumps({"method": name, "official": records[name]["official"], "wall": elapsed}), flush=True)

# Test references are used only for post-scoring descriptive comparisons.
check_data(DATA, ("test",))
bank, arrays = load_inputs("test")
gold = read_jsonl(DATA / "gsm8k_test.jsonl")
assert [(r["id"], r["question"]) for r in bank] == [(r["id"], r["question"]) for r in gold]
answers = [parse_answer(row["answer"]) for row in gold]
groups = [answer_groups(row["candidates"]) for row in bank]
counts = np.array([len(group) for group in groups])
paths = {name: OUT / name / "test" for name in specs}
paths.update({name: RUNS / run / "test" for name, run in (
    ("m1_64", "mlp_text_v1"), ("ensemble_64", "ensemble_v1"), ("linear", "linear_v1"),
    ("linear_text", "linear_text_v1"), ("calibrated", "calibrated_ensemble_v1"))})
correctness = {}
for name, folder in paths.items():
    prediction = read(folder / "predictions.json")
    validate_choices(bank, prediction["ids"], prediction["selected"])
    correct = np.array([parse_answer(row["candidates"][j]["text"]) == answer
                       for row, j, answer in zip(bank, prediction["selected"], answers)])
    assert int(correct.sum()) == read(folder / "score.json")["correct"]
    correctness[name] = correct
for name, (kind, width) in specs.items():
    output = OUT / name / "test"
    choices, profile = modules[kind].predict_profiled(bank, arrays, OUT / name / "checkpoint", include_scores=True)
    assert choices == read(output / "predictions.json")["selected"]
    scores = profile.pop("group_scores")
    correct = correctness[name]
    analysis = {"scope": plan["test_policy"], "correct": int(correct.sum()), "wrong": int((~correct).sum()),
        "by_group_count": {str(g): accuracy(correct[counts == g]) for g in sorted(set(counts))},
        "profile_replay": profile, "confidence": confidence_summary(scores, groups, answers, correct, counts >= 2)}
    for other, reference in correctness.items():
        if name != other:
            analysis["vs_" + other] = {**comparison(correct, reference),
                "official": read(paths[other] / "score.json"),
                "predictions_sha256": sha(paths[other] / "predictions.json")}
    records[name]["analysis"] = analysis
    records[name]["frozen_files_unchanged"] = all(sha(ROOT / p) == digest for p, digest in freezes[name]["sha256"].items())
    records[name]["historical_artifacts_unchanged"] = all(sha(ROOT / p) == digest for p, digest in historical.items())
    assert records[name]["frozen_files_unchanged"] and records[name]["historical_artifacts_unchanged"]
    assert sha(output / "predictions.json") == read(output / "prediction_freeze.json")["predictions_sha256"]
    write(output / "summary.json", records[name])
summary = {"created_utc": now(), "plan": plan, "validation_selection": selection,
    "test_used_for_selection": False, "fit_count": 12,
    "training_seconds": sum(read(OUT / f"m1_{w}/training.json")["training_seconds"] for w in (128, 256)),
    "historical_artifact_count": len(historical), "historical_artifacts_unchanged": True,
    "methods": {name: {"validation": selection_candidates[name], "test": record["official"],
        "test_seconds": record["total_wall_seconds"], "inference_asset_bytes": record["inference_asset_bytes"],
        "vs_original_member": record["analysis"]["vs_" + ("m1_64" if name.startswith("m1") else "ensemble_64")],
        "eligibility": record["eligibility"]} for name, record in records.items()}}
write(OUT / "summary.json", summary)
print(json.dumps(summary, ensure_ascii=False), flush=True)
