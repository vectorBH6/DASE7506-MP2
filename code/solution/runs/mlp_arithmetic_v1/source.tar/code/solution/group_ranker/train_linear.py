"""仅用 train 拟合线性答案组排序器：按题交叉验证，导出纯 NumPy 权重。"""
import os

# 在导入数值库前限制线程；训练与后续复现实验都使用 CPU。
for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[variable] = "4"

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

import numpy as np
import scipy
from scipy.optimize import minimize

from common import DATA, PROTOCOL
from solution.group_ranker.features import (
    FEATURE_DIM, FEATURE_VERSION, standardize,
)
from solution.group_ranker.training import (
    export_model, fit_standardizer, make_folds, metrics, prepare_training, write_json,
)


def objective(weight, x, mask, labels, l2):
    """平均组交叉熵及解析梯度；L2 约定为 l2/2 * ||w||²。"""
    n = len(labels)
    scores = (x @ weight).reshape(mask.shape)
    scores = np.where(mask, scores, -np.inf)
    shifted = scores - scores.max(axis=1, keepdims=True)
    exp_scores = np.exp(shifted)
    denominator = exp_scores.sum(axis=1, keepdims=True)
    nll = np.mean(np.log(denominator[:, 0]) - shifted[np.arange(n), labels])
    residual = exp_scores / denominator
    residual[np.arange(n), labels] -= 1
    gradient = x.T @ residual.ravel() / n + l2 * weight
    return nll + l2 * (weight @ weight) / 2, gradient


def fit_linear(features, mask, labels, l2, maxiter):
    model = fit_standardizer(features, mask)
    x = standardize(features, **model).astype(np.float64).reshape(-1, FEATURE_DIM)
    result = minimize(
        objective, np.zeros(FEATURE_DIM), args=(x, mask, labels, l2),
        method="L-BFGS-B", jac=True,
        options={"maxiter": maxiter, "ftol": 1e-9, "gtol": 1e-6},
    )
    if not np.isfinite(result.fun) or not np.isfinite(result.x).all():
        raise RuntimeError("优化结果非有限，停止导出")
    model["weight"] = result.x.astype(np.float32)
    status = {"converged": bool(result.success), "iterations": int(result.nit),
              "objective": float(result.fun), "message": str(result.message)}
    return model, status


def group_scores(features, mask, model):
    x = standardize(features, model["mean"], model["scale"], model["active"])
    return np.where(mask, x @ model["weight"], -np.inf)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=DATA)
    parser.add_argument("--output", type=Path, required=True, help="新实验目录，例如 solution/runs/linear_v2")
    parser.add_argument("--l2", nargs="+", type=float, default=[1e-4, 1e-3, 1e-2])
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--seed", type=int, default=7506)
    parser.add_argument("--maxiter", type=int, default=300)
    args = parser.parse_args()
    if args.folds < 2 or args.maxiter < 1 or any(v <= 0 for v in args.l2):
        parser.error("folds 至少为 2，maxiter 和 l2 必须为正")
    if args.output.exists() and any(args.output.iterdir()):
        parser.error("输出目录已含文件；请使用新的实验目录，保留旧记录")
    tick = time.perf_counter()
    features, mask, labels, patterns, total = prepare_training(args.data_dir)
    if args.folds > min(Counter(patterns).values()):
        parser.error("folds 超过最小票型样本数")
    fold_ids = make_folds(patterns, args.folds, args.seed)
    records, oof_scores = [], []
    for l2 in args.l2:
        scores = np.full(mask.shape, -np.inf, dtype=np.float32)
        fold_records = []
        for fold in range(args.folds):
            train, valid = fold_ids != fold, fold_ids == fold
            model, status = fit_linear(features[train], mask[train], labels[train], l2, args.maxiter)
            scores[valid] = group_scores(features[valid], mask[valid], model)
            fold_records.append({"fold": fold, **metrics(scores[valid], labels[valid]), **status})
            print(f"l2={l2:g}, fold={fold}: {fold_records[-1]}", flush=True)
        records.append({"l2": l2, "oof": metrics(scores, labels), "folds": fold_records})
        oof_scores.append(scores)
    # 只看 train OOF；准确率、NLL 依次比较，再优先更强的正则。
    selected = min(range(len(records)), key=lambda i: (
        -records[i]["oof"]["accuracy"], records[i]["oof"]["nll"], -records[i]["l2"],
    ))
    best_l2 = records[selected]["l2"]
    model, status = fit_linear(features, mask, labels, best_l2, args.maxiter)
    args.output.mkdir(parents=True, exist_ok=True)
    config = {
        "protocol": PROTOCOL, "feature_version": FEATURE_VERSION, "feature_dim": FEATURE_DIM,
        "model": "linear", "enabled_scalar_indices": list(range(16)), "l2": best_l2,
        "seed": args.seed, "folds": args.folds, "maxiter": args.maxiter,
        "training_split": "train", "training_questions": len(labels),
    }
    asset_bytes = export_model(args.output / "checkpoint", model, config)
    # OOF 与标签只存训练记录目录，不放入推理 checkpoint。
    np.savez(args.output / "oof.npz", scores=oof_scores[selected], labels=labels, folds=fold_ids)
    sources = [Path(__file__), Path(__file__).with_name("training.py"), Path(__file__).with_name("features.py"),
               Path(__file__).with_name("submission_linear.py")]
    report = {
        "created_utc": datetime.now(timezone.utc).isoformat(), "config": config,
        "train_total": total, "train_conflict": len(labels),
        "search": records, "selected_l2": best_l2, "final_optimizer": status,
        "inference_asset_bytes": asset_bytes, "training_seconds": time.perf_counter() - tick,
        "environment": {"python": sys.version.split()[0], "numpy": np.__version__,
                        "scipy": scipy.__version__, "platform": platform.platform(), "threads": 4},
        "source_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
        "data_manifest_sha256": hashlib.sha256((args.data_dir / "manifest.json").read_bytes()).hexdigest(),
    }
    write_json(args.output / "training.json", report)
    print(json.dumps({"selected_l2": best_l2, "oof": records[selected]["oof"],
                      "asset_bytes": asset_bytes, "training_seconds": report["training_seconds"]},
                     indent=2), flush=True)


if __name__ == "__main__":
    main()
