"""调用官方 validation 工具，比较基线、线性和可选 MLP，保存资源与分层记录。"""
import os

THREAD_VARIABLES = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "BLIS_NUM_THREADS")
for variable in THREAD_VARIABLES:
    os.environ[variable] = "1"

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parent
OFFICIAL = ROOT.parent

from common import DATA, check_data, load_inputs, parse_answer, read_jsonl
from solution.group_ranker.features import answer_groups

# 方法文件与是否需要 checkpoint 只在此登记；新增模型无需改动评分流程。
METHODS = {
    "baseline": ("baselines/submission.py", None),
    "voting": ("baselines/submission_voling_only.py", None),
    "embedding": ("baselines/submission_emb_only.py", None),
    "b1": ("baselines/submission_tiebreak.py", None),
    "b2": ("baselines/submission_group_center.py", None),
    "linear": ("group_ranker/submission_linear.py", "linear"),
    "mlp": ("group_ranker/submission_mlp.py", "mlp"),
}


def thread_count(pid):
    try:
        return next(int(line.split()[1]) for line in Path(f"/proc/{pid}/status").read_text().splitlines()
                    if line.startswith("Threads:"))
    except (FileNotFoundError, ProcessLookupError):
        return 0


def run_official(command, env):
    """Linux 下每毫秒采样父/子进程线程；监测工作在父进程主线程完成。"""
    monitored = Path("/proc/self/status").exists()
    peaks = {"coordinator_peak_threads": 0, "child_peak_threads": 0, "total_peak_threads": 0}
    samples = 0
    with subprocess.Popen(command, cwd=OFFICIAL, env=env, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, text=True) as process:
        while process.poll() is None:
            if monitored:
                parent, child = thread_count(os.getpid()), thread_count(process.pid)
                for key, value in zip(peaks, (parent, child, parent + child)):
                    peaks[key] = max(peaks[key], value)
                samples += 1
            time.sleep(0.001)
        stdout, stderr = process.communicate()
        if process.returncode:
            raise subprocess.CalledProcessError(process.returncode, command, stdout, stderr)
    if monitored and peaks["total_peak_threads"] > 4:
        raise RuntimeError(f"评测总线程超过 4：{peaks}")
    return {"command": command, "stdout": stdout, "stderr": stderr, "thread_samples": samples,
            **(peaks if monitored else dict.fromkeys(peaks))}


def accuracy(correct):
    n = len(correct)
    return {"correct": int(np.sum(correct)), "n": n,
            "accuracy": float(100 * np.mean(correct)) if n else None}


def bootstrap_interval(difference):
    """同一批题成对抽样；返回准确率差值的百分点区间。"""
    rng = np.random.default_rng(7506)
    sampled = rng.choice(difference, size=(2000, len(difference)), replace=True)
    return (100 * np.quantile(sampled.mean(axis=1), [0.025, 0.975])).tolist()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True, help="线性模型 checkpoint")
    parser.add_argument("--mlp-checkpoint", type=Path, nargs="+", help="同时比较 M0/M1/M2 的 checkpoint")
    parser.add_argument("--output", type=Path, help="默认写入该实验的 validation/ 目录")
    args = parser.parse_args()
    if args.output is None:
        args.output = (args.mlp_checkpoint[-1] if args.mlp_checkpoint else args.checkpoint).parent / "validation"
    checkpoints = {"linear": args.checkpoint.resolve()}
    methods = {name: entry for name, entry in METHODS.items() if name != "mlp"}
    for directory in args.mlp_checkpoint or []:
        config = json.loads((directory / "config.json").read_text(encoding="utf-8"))
        name = {"basic": "mlp", "text": "m1", "arithmetic": "m2"}[config.get("feature_set", "basic")]
        if name in checkpoints:
            parser.error(f"重复的 MLP 特征组：{name}")
        checkpoints[name] = directory.resolve()
        methods[name] = ("group_ranker/submission_mlp.py", name)
    if any(not (directory / "model.npz").is_file() for directory in checkpoints.values()):
        parser.error("请先训练并指定已有 checkpoint")
    if args.output.exists() and any(args.output.iterdir()):
        parser.error("输出目录已含记录，请使用新的 --output 目录")
    args.output.mkdir(parents=True, exist_ok=True)
    output = args.output.resolve()
    # 编排进程占 1 线程，官方子进程最多 3 线程；两者合计不超过 4。
    child_env = {**os.environ, **dict.fromkeys(THREAD_VARIABLES, "3")}
    records, predictions = {}, {}
    for name, (method, checkpoint_name) in methods.items():
        prediction_path, score_path = output / f"{name}-predictions.json", output / f"{name}-score.json"
        command = [
            sys.executable, str(OFFICIAL / "predict.py"), "--method", str(ROOT / method),
            "--split", "validation", "--output", str(prediction_path),
        ]
        if checkpoint_name:
            command += ["--checkpoint", str(checkpoints[checkpoint_name])]
        scoring = [
            sys.executable, str(OFFICIAL / "score_predictions.py"), "--split", "validation",
            "--predictions", str(prediction_path), "--output", str(score_path),
        ]
        # 外部计时覆盖两个新进程，包含启动、import、哈希检查与载入。
        tick = time.perf_counter()
        processes = [run_official(process_command, child_env) for process_command in (command, scoring)]
        elapsed = time.perf_counter() - tick
        records[name] = {
            "official": json.loads(score_path.read_text(encoding="utf-8")),
            "total_wall_seconds": elapsed, "commands": [command, scoring], "processes": processes,
            "method_sha256": hashlib.sha256((ROOT / method).read_bytes()).hexdigest(),
        }
        records[name]["inference_asset_bytes"] = (
            sum(p.stat().st_size for p in checkpoints[checkpoint_name].iterdir() if p.is_file())
            if checkpoint_name else 0)
        predictions[name] = json.loads(prediction_path.read_text(encoding="utf-8"))["selected"]
        print(f"{name}: accuracy={records[name]['official']['accuracy']:.4f}%, wall={elapsed:.3f}s", flush=True)

    # 参考答案仅在分析阶段读取，不传给任何 predict 函数。
    check_data(DATA, ("validation",))
    bank, arrays = load_inputs("validation")
    # 单独重放无标签预测以记录特征/前向耗时，完整资源计时仍以上方新进程为准。
    from solution.group_ranker.submission_mlp import predict_profiled

    for name in ("mlp", "m1", "m2"):
        if name in checkpoints:
            choices, profile = predict_profiled(bank, arrays, checkpoints[name])
            if choices != predictions[name]:
                raise ValueError("分析重放与官方预测不一致")
            records[name]["profile_replay"] = profile
    gold = read_jsonl(DATA / "gsm8k_validation.jsonl")
    answers = [parse_answer(row["answer"]) for row in gold]
    groups = [answer_groups(row["candidates"]) for row in bank]
    group_counts = np.array([len(g) for g in groups])
    hard = group_counts >= 2
    patterns = np.array(["+".join(map(str, sorted((len(v) for v in g.values()), reverse=True))) or "none"
                         for g in groups])
    correctness = {}
    for name, choices in predictions.items():
        selected = [parse_answer(row["candidates"][j]["text"]) for row, j in zip(bank, choices)]
        correct = np.array([a is not None and a == reference for a, reference in zip(selected, answers)])
        if int(correct.sum()) != records[name]["official"]["correct"]:
            raise ValueError("分析指标与官方评分不一致")
        correctness[name] = correct
        records[name]["conflict"] = accuracy(correct[hard])
        records[name]["by_group_count"] = {
            str(g): accuracy(correct[group_counts == g]) for g in sorted(set(group_counts))}
        records[name]["by_vote_pattern"] = {
            p: accuracy(correct[patterns == p]) for p in sorted(set(patterns))}
    equivalent = bool(np.array_equal(correctness["baseline"], correctness["voting"]))
    if not equivalent:
        raise ValueError("主基线与纯投票的逐题得分不一致，需要检查实现")
    baseline = correctness["baseline"]
    for name, correct in correctness.items():
        records[name]["corrected_vs_baseline"] = int(np.sum(~baseline & correct))
        records[name]["regressed_vs_baseline"] = int(np.sum(baseline & ~correct))
        if name != "baseline":
            difference = correct.astype(int) - baseline.astype(int)
            records[name]["difference_95ci_pp"] = bootstrap_interval(difference)
            records[name]["conflict_difference_95ci_pp"] = bootstrap_interval(difference[hard])
        for reference_name in ("linear", "mlp", "m1"):
            if name == reference_name or reference_name not in correctness:
                continue
            reference = correctness[reference_name]
            difference = correct.astype(int) - reference.astype(int)
            records[name][f"vs_{reference_name}"] = {
                "corrected": int(np.sum(~reference & correct)),
                "regressed": int(np.sum(reference & ~correct)),
                "difference_95ci_pp": bootstrap_interval(difference),
                "conflict_difference_95ci_pp": bootstrap_interval(difference[hard]),
            }
    cpuinfo = Path("/proc/cpuinfo")
    cpu = next((line.split(":", 1)[1].strip() for line in cpuinfo.read_text().splitlines()
                if line.startswith("model name")), platform.processor()) if cpuinfo.exists() else platform.processor()
    report = {
        "created_utc": datetime.now(timezone.utc).isoformat(), "split": "validation",
        "n": len(bank), "conflict_n": int(hard.sum()),
        "baseline_voting_score_equivalent": equivalent,
        "environment": {"python": sys.version.split()[0], "numpy": np.__version__,
                        "cpu": cpu, "platform": platform.platform(),
                        "thread_budget_total": 4, "coordinator_threads": 1, "child_threads": 3},
        "methods": records,
        "checkpoint_sha256": {name: {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                     for p in directory.iterdir() if p.is_file()}
                              for name, directory in checkpoints.items()},
        "source_sha256": {str(p.relative_to(OFFICIAL)): hashlib.sha256(p.read_bytes()).hexdigest()
                          for directory in (ROOT, ROOT / "baselines", ROOT / "group_ranker")
                          for p in sorted(directory.glob("*.py"))},
        "data_manifest_sha256": hashlib.sha256((DATA / "manifest.json").read_bytes()).hexdigest(),
    }
    (output / "summary.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"记录已保存：{output / 'summary.json'}")


if __name__ == "__main__":
    main()
