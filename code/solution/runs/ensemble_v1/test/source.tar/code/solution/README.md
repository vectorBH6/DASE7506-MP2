# MP2 作业实现

资料：[算法路线](../../class%20pdf/MP2最终算法路线.md) · [课程知识点](../../class%20pdf/MP2算法知识点总结与方案灵感.md) · [作业要求](../../guide/GUIDE.md) · [官方运行说明](../README_cn.md)。

当前：**M1：文本特征 + CE 小 MLP** 已冻结并完成本机完整 test，**372/467，79.65738758029978%**。权重位于 `runs/mlp_text_v1/checkpoint/`；参考机测时、报告和公开交付待完成。

## 结构

```text
code/
├── common.py、predict.py、score_predictions.py、data/ …  # 课程原始文件
└── solution/                  # 作业实现，按功能组织
    ├── baselines/             # 原基线、两项原消融、B1 平票与 B2 组中心性
    ├── group_ranker/          # 共享特征/训练工具，线性与 MLP，预测接口与检查
    ├── evaluate.py            # 调用官方工具，统一验证与记录
    ├── requirements-train.txt
    └── runs/<实验名>/         # checkpoint/、训练记录、validation/、冻结后的 test/
```

源码在 `solution/` 中复用和扩展；每轮产物集中到对应实验目录，已有记录不覆盖。`runs/` 与虚拟环境默认由 Git 忽略；`linear_v1` 的权重及训练、验证、冻结测试记录作为复现快照随仓库提交。历史 JSON 保留生成时的命令和路径。

官方 `common.py` 负责数据与答案解析，`predict.py`、`score_predictions.py` 负责独立预测与评分；本目录只实现算法、训练和实验编排。

本文件只维护运行入口和简短结果；算法推导见路线文档，详细 CV、分层指标、耗时与哈希以实验目录内 JSON 为准。

特征版本在 `group_ranker/features.py` 的 `FEATURE_VERSIONS` 中登记；配置记录启用的标量范围，旧 checkpoint 继续使用原基础特征。

## 运行

以下命令从 **`code/`** 执行，Python 3.12。通过 `python -m solution.…` 运行，自然导入同目录的官方 `common.py`，无需手工修改 `sys.path`。

首次安装；已有环境跳过：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
python3 -m venv solution/.venv-train
solution/.venv-train/bin/python -m pip install -r solution/requirements-train.txt
```

线性训练与六方法验证（包含 B1/B2）；`linear_v1` 已有归档，新实验使用新名称：

```bash
run_dir=solution/runs/linear_v2
solution/.venv-train/bin/python -m solution.group_ranker.train_linear --output "$run_dir"
.venv/bin/python -m solution.evaluate --checkpoint "$run_dir/checkpoint"
```

线性训练按题五折 CV、种子 7506，仅比较预设的三个 L2 系数。MLP 训练及七方法比较：

```bash
run_dir=solution/runs/mlp_v2
solution/.venv-train/bin/python -m solution.group_ranker.train_mlp --output "$run_dir"
.venv/bin/python -m solution.evaluate \
  --checkpoint solution/runs/linear_v1/checkpoint \
  --mlp-checkpoint "$run_dir/checkpoint"
```

`mlp_v1` 已有本轮记录，命令使用新名称以免覆盖。训练环境沿用 `requirements-train.txt`；本次实际用相同版本的系统 `python3` 训练。MLP 的前向、反传和 AdamW 均用 NumPy 实现，数据准备、按题划分、标准化和导出共用 `group_ranker/training.py`。

P2 分别启用文本、文本加算术特征，复用 M0 的已选配置；每版只做五折 OOF 和一次全量重训，轮数仍取折内最佳轮数中位数。运行时使用新的实验目录：

```bash
base=solution/runs/mlp_v1/checkpoint
text_run=solution/runs/mlp_text_v2
arithmetic_run=solution/runs/mlp_arithmetic_v2
solution/.venv-train/bin/python -m solution.group_ranker.train_mlp \
  --feature-set text --reuse-config "$base/config.json" --output "$text_run"
solution/.venv-train/bin/python -m solution.group_ranker.train_mlp \
  --feature-set arithmetic --reuse-config "$base/config.json" --output "$arithmetic_run"
.venv/bin/python -m solution.evaluate \
  --checkpoint solution/runs/linear_v1/checkpoint \
  --mlp-checkpoint "$base" "$text_run/checkpoint" "$arithmetic_run/checkpoint"
```

本轮 P2 目录为 `mlp_text_v1`、`mlp_arithmetic_v1`。同一 `submission_mlp.py` 按配置提取特征，`evidence.py` 实现文本与有界算术检查，不复制阶段源码。`mlp_v1/source.tar` 保存增加 P2 特征前的 M0 源码。

P3 复用 M1 配置，四项特征消融各自重训，另比较 pairwise loss；不同时改变两项设计。以下使用新目录 `p3_repeat`，本轮记录在 `runs/p3/`：

```bash
base=solution/runs/mlp_text_v1/checkpoint/config.json
out=solution/runs/p3_repeat
for block in no_votes no_embedding no_context no_style; do
  solution/.venv-train/bin/python -m solution.group_ranker.train_mlp \
    --feature-set text --reuse-config "$base" --ablation "$block" --output "$out/$block" || break
done
solution/.venv-train/bin/python -m solution.group_ranker.train_mlp \
  --feature-set text --reuse-config "$base" --loss pairwise --output "$out/pairwise"
solution/.venv-train/bin/python -m solution.group_ranker.train_mlp \
  --feature-set text --reuse-config "$base" --stability-only --output "$out/stability"
.venv/bin/python -m solution.evaluate \
  --checkpoint solution/runs/linear_v1/checkpoint \
  --mlp-checkpoint solution/runs/mlp_v1/checkpoint \
    solution/runs/mlp_text_v1/checkpoint solution/runs/mlp_arithmetic_v1/checkpoint \
    "$out/no_votes/checkpoint" "$out/no_embedding/checkpoint" \
    "$out/no_context/checkpoint" "$out/no_style/checkpoint" "$out/pairwise/checkpoint" \
  --output "$out/validation"
```

`--stability-only` 只输出固定划分下 7507/7508 的 OOF 记录，不导出其他种子的候选模型。所有版本使用相同的折内 CE NLL 早停规则；pairwise 只改变训练损失。选型预先固定为完整 validation 准确率最高，同分依次比较更少启用维度、更少推理资产、更短完整耗时。`mlp_arithmetic_v1/source.tar` 保存 P3 修改前的 P2 源码。

评测默认写到最后一个 MLP（若提供）或线性实验的 `validation/`，也可用 `--output` 指定新目录。训练数值库设置为 4 线程；评测编排进程占 1 线程，顺序启动的官方子进程最多 3 线程，合计最多 4 线程。Linux 下逐进程记录实测线程峰值。所有开发比较仅使用 validation；`profile_replay` 是额外无标签重放的特征/标准化加前向计时，完整资源计时以新进程的 `total_wall_seconds` 为准。

检查：

```bash
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 BLIS_NUM_THREADS=1
solution/.venv-train/bin/python -m unittest solution.group_ranker.test_group_ranker -v
.venv/bin/python -m unittest solution.group_ranker.test_group_ranker -v
```

检查覆盖线性、MLP、特征消融与算术边界；纯 NumPy 环境只跳过需要 SciPy 的线性梯度检查，MLP 的 CE/pairwise 梯度差分仍执行。训练本身采用 NumPy，因此前向一致性采用独立的逐组标量计算核对批量前向。候选置换比较映射后的解析答案；“同组代表替换”只要求官方最终数值评分不变，不要求改写候选正文后特征不变。

推理入口为 `solution/group_ranker/submission_linear.py` 或 `submission_mlp.py`，均实现 `predict(bank, arrays, checkpoint)`，为每题返回一个 0–3 的 Python 整数。作业允许自定义文件名，通过 `--method` 传入；官方 `submission.py` 保留原始占位接口。

直接使用官方工具时，预留 1 线程给外层编排，并顺序运行预测、评分：

```bash
export OMP_NUM_THREADS=3 OPENBLAS_NUM_THREADS=3 MKL_NUM_THREADS=3 BLIS_NUM_THREADS=3
```

## 实验摘要

`linear_v1`，2026-10-18：遍历全部 4,755 道 train 题；其中 2,641 道单答案组题无需组间决策，其余 2,114 道冲突题进行五折 OOF，选择 L2=0.01 后，再用全部 2,114 题从头训练最终模型。随后在完整 validation 上比较方法。

| 方法 | 完整 validation | 冲突题 |
|---|---:|---:|
| 原基线 / 纯投票 | 688/798，86.22% | 245/355，69.01% |
| 纯 embedding | 624/798，78.20% | 200/355，56.34% |
| B1：最多票组平票时按中心性选择 | 677/798，84.84% | 234/355，65.92% |
| B2：答案组中心性 | 610/798，76.44% | 167/355，47.04% |
| 线性答案组排序 | 730/798，91.48% | 287/355，80.85% |
| M0：相同基础特征的小 MLP | 733/798，91.85% | 290/355，81.69% |
| M1：M0 增加文本/题目关系 | **738/798，92.48%** | **295/355，83.10%** |
| M2：M1 增加局部算术 | 733/798，91.85% | 290/355，81.69% |

线性模型在 validation 净增 42 题。修正评测总线程配置后，四种方法的逐题选择均与原记录一致。冻结前检查：训练环境 7 项通过；纯 NumPy 推理环境 6 项通过、1 项训练梯度检查因无 SciPy 跳过。

### B1/B2 与 M0：2026-10-18

- **规则**：候选中心性为与其他有效候选的平均余弦，排除自身；组分数为组内候选中心性的均值。B1 仅比较并列最多票组，B2 比较全部有效答案组。两者均复用官方答案解析，不训练。
- **相同特征**：M0 沿用 2,088 维基础特征与标量 0–15，16–39 仍为零。四配置为隐层 `(64,16)/(32,16)` × weight decay `0.01/0.1`。AdamW 学习率 `0.001`、dropout `0.1`、batch 为 64 道题、梯度范数上限 1；最多 150 轮，折内 NLL 连续 15 轮无改善则早停。
- **选型**：仅按 train 五折 OOF 选择 `64→16`、weight decay `0.01`；最佳轮数 `[5,4,5,4,4]` 的中位数为 4，随后在全部 2,114 道训练冲突题上重训。折划分种子固定 7506，最终模型种子固定 7506；7507/7508 仅做 OOF 稳定性复核，不挑种子或集成。
- **结果解释**：线性 OOF 为 81.13%，MLP OOF 为 79.09%，复核为 78.43%/78.71%。MLP 在 validation 相比线性纠正 13 题、改错 10 题，净增 3 题；完整 validation 差值的 paired bootstrap 95% 区间为 **[-0.88, 1.63] 个百分点**，当前证据不足以证明稳定优势。B1/B2 均未改善原投票基线。特征与关键消融结果见下文 P2/P3。
- **资源**：CPU 完成 20 次选型折训练、10 次复核折训练及 1 次最终重训，共约 **307.73 秒**。MLP 未压缩推理资产 **560,785 字节（约 0.535 MiB）**；本机完整 validation 预测加独立评分约 **0.265 秒**。七种方法的预测、评分阶段实测总线程峰值均为 **4**。这些是本机 validation 资源记录，参考机资格另行确认。

完整记录：[训练与搜索](runs/mlp_v1/training.json) · [七方法比较、分层、耗时与线程](runs/mlp_v1/validation/summary.json) · [MLP 官方评分](runs/mlp_v1/validation/mlp-score.json) · [checkpoint](runs/mlp_v1/checkpoint/)。本轮未评测 test。

### P2：文本与算术，2026-10-19

M1 启用标量 16–31：长度、重复、问题与正文的词/数字关系，以及答案与题目数值的关系。M2 在 M1 上启用 32–39：已检查等式的数量、通过率、矛盾率和覆盖标志。算术使用受限 AST 与 Fraction，仅检查明确边界中的纯数字等式；不生成答案，不执行候选代码，也不因局部计算错误直接否决答案组。精确定义及限制见算法路线 §4。

两版均复用 M0 的 `64→16`、weight decay `0.01` 及其余训练参数，不另搜结构、正则或种子；固定原五折划分，各折独立标准化与早停。M1 最佳轮数 `[5,5,5,3,6]`，最终重训 5 轮；M2 为 `[4,3,5,4,3]`，最终重训 4 轮。

| 方法 | train OOF（冲突题） | 完整 validation | 本机完整预测 + 评分 | 推理资产 |
|---|---:|---:|---:|---:|
| 线性 L0 | 1715/2114，81.13% | 730/798，91.48% | 0.263 秒 | 28,771 字节 |
| 基础 M0 | 1672/2114，79.09% | 733/798，91.85% | 0.265 秒 | 560,785 字节 |
| 文本 M1 | 1692/2114，80.04% | **738/798，92.48%** | 0.382 秒 | 560,937 字节 |
| 算术 M2 | 1674/2114，79.19% | 733/798，91.85% | 0.440 秒 | 561,013 字节 |

- **文本有初步收益**：M1 相比 M0 在 validation 纠正 9 题、改错 4 题，净增 5 题；相比线性净增 8 题。但相对 M0 的完整 validation 差值 95% 区间为 `[-0.25, 1.50]` 个百分点，仍跨 0；目前不能声称稳定优势。
- **算术未带来增益**：M2 相比 M1 纠正 6 题、改错 11 题，净减 5 题，OOF 也下降。保持记录，当前候选关闭算术块。这里比较的是相同训练协议下的重训版本，轮数由各自 OOF 早停确定，并非固定权重后直接增减特征。
- **覆盖有限**：train 成功检查覆盖 `1037/2114` 道冲突题、`1950/8082` 个有效候选；validation 为 `155/355` 题（43.66%）、`296/1344` 个有效候选（22.02%）。validation 共检查 420 条等式，其中 402 条通过、18 条矛盾；另有 6,405 个未能检查的数学/美元符号片段，未知不计为错误。局部算式通过也不能证明题意理解正确。
- **成本**：M1/M2 各 5 次折训练加 1 次全量重训，分别约 69.60/66.01 秒。validation 单线程分析重放中，特征提取约 0.158/0.216 秒，标准化加前向约 0.004/0.004 秒；M2 其中算术检查约 0.045 秒。九种方法新进程预测及评分阶段实测总线程峰值均为 4。本机耗时不能代替参考机认证。

P2 按预设 validation 标准选 M1 进入 P3，线性和 M0 保留为对照；后续结果见下节。P2 未运行 test，也未根据旧 test 结果修改特征或参数。

记录：[M1 训练](runs/mlp_text_v1/training.json) · [M2 训练](runs/mlp_arithmetic_v1/training.json) · [九方法 validation、分层、比较与资源](runs/mlp_arithmetic_v1/validation/summary.json) · [M1 checkpoint](runs/mlp_text_v1/checkpoint/) · [M2 checkpoint](runs/mlp_arithmetic_v1/checkpoint/)。

### P3：有限选型与检查，2026-10-19

本轮预先固定五项消融，复用 M1 的网络与优化参数，每项五折 OOF 后全量重训；另对原 M1 做两个种子的 OOF 复核。所有模型保持 2,088 维输入 schema，以掩码关闭特征，消融版本仍存储相同形状的权重。标量索引与向量区间均为左闭右开。

| 方案 | 移除或改变的内容 | train OOF | 完整 validation | 冲突题 |
|---|---|---:|---:|---:|
| 原 M1 | 文本 + CE，对照 | 80.04% | **738/798，92.48%** | **295/355，83.10%** |
| no_votes | 标量 `[0,8)` | 79.85% | 736/798，92.23% | 293/355，82.54% |
| no_embedding | 两个向量块及几何标量 `[8,16)` | 73.56% | 709/798，88.85% | 266/355，74.93% |
| no_context | 仅交互向量 `[1024,2048)` | 79.38% | 732/798，91.73% | 289/355，81.41% |
| no_style | 长度/数字密度/重复标量 `[16,24)` | 79.19% | 735/798，92.11% | 292/355，82.25% |
| pairwise | 同特征，CE 换成按题归一化的成对损失 | 78.29% | 736/798，92.23% | 293/355，82.54% |

- **表示信息贡献最明显**：去 embedding 版本相比 M1 纠正 12 题、改错 41 题，净减 29 题；完整 validation 差值 95% 区间为 `[-5.39,-1.88]` 个百分点。该消融同时移除了依赖 embedding 的几何标量，不能单独归因到某一个向量块。
- **其余差异较小**：去票数、交互、风格、换损失分别净减 2、6、3、2 题，差值区间均跨 0。去显式票数后仍有组 pooling、范数等间接重复信息；去交互向量仍保留其他几何标量。因此这些消融不代表彻底消除了所有票数/题内关系。风格块的作用也不能证明模型掌握了完整推理验证。
- **稳定性**：固定划分 7506，M1 在训练种子 7506/7507/7508 下 OOF 为 `80.04% / 79.04% / 79.75%`；同种子的 M0 为 `79.09% / 78.43% / 78.71%`。最终种子仍为 7506，复核不用于挑种子或集成。线性 OOF 81.13% 仍更高；选型遵循预设的完整 validation 标准。
- **有限选型结果**：14 种方法比较后，继续选原 M1，checkpoint 未改动。它比线性在 validation 净增 8 题，但差值区间 `[-0.25,2.38]` 个百分点仍跨 0。所有 bootstrap 区间均未校正多次比较，不能将本次选型写成确定的泛化优势。
- **置信度**：M1 冲突题 NLL 为 0.4781；最高组概率在 `[0.85,0.95)` 的 67 题中只答对 54 题（80.60%）。softmax 是未校准的相对分数，不直接等于正确概率；本轮未拟合温度或阈值。
- **资源与检查**：共 40 次训练，累计约 **499.65 秒**；训练环境 17 项全通过，纯 NumPy 环境 16 项通过、1 项线性 SciPy 检查跳过。14 种方法实测总线程峰值均为 4，历史线性/M0/M1/M2 逐题选择不变，OOF 标签与 fold 一致，官方代码哈希不变。M1 本机完整 validation 预测加独立评分约 **0.385 秒**，推理资产 **560,937 字节**；参考机资格待确认。

P3 阶段未运行 test；后续 M1 冻结 test 结果见下节。参考机测时、报告、复用披露和公开交付待完成；旧线性冻结记录保留。

记录：[14 方法与选型](runs/p3/validation/summary.json) · [稳定性复核](runs/p3/stability/training.json) · [检查结果和命令](runs/p3/checks.json)。各消融的权重、训练过程和 OOF 分数位于 `runs/p3/<方案>/`，validation JSON 包含各票型、组数、置信度分桶与纠错/改错案例。

### M1 冻结 test，2026-10-19

先保存源码快照、代码/配置/权重 SHA-256 与 P3 选型依据，再仅运行已选 M1 的完整 test 官方预测及独立评分。冻结 ID 前缀 `1147e6f4ce3b`；测试后冻结文件哈希保持不变。当前工作区含未提交源码，精确冻结版本由 `source.tar` 与 SHA-256 清单标识。

| 项目 | 结果 |
|---|---:|
| 官方完整 test accuracy | **372/467，79.65738758029978%** |
| 错题数 | 95 |
| 本机新进程预测 + 独立评分 | **0.405 秒** |
| 实测总线程峰值 | **4**（编排 1 + 子进程 3） |
| 未压缩推理资产 | **560,937 字节**，约 0.535 MiB |

- **与 validation 的关系**：test 467 题全是冲突题；validation 有 443 道单答案组题。对应的冲突题准确率为 validation `295/355，83.10%`，test `372/467，79.66%`，下降约 3.44 个百分点。
- **与历史线性结果比较**：旧线性为 `375/467，80.30%`。M1 纠正 23 题、改错 26 题，净减 3 题（-0.64 个百分点）；配对 bootstrap 95% 区间为 `[-3.64,2.36]` 个百分点，不能据此认定两者存在稳定优劣。validation 上 M1 的收益未在本次 test 重现。
- **分歧越多仍越难**：M1 在 2/3/4 个有效答案组的问题上分别为 `266/303（87.79%）`、`85/126（67.46%）`、`21/38（55.26%）`。相比旧线性分别净增 3、净减 8、净增 2 题；本次净差主要来自三答案组题。

以上为冻结后的描述性评分分析，不用于调参、换种子、集成或重选模型。耗时包含两个新进程的启动、导入、哈希校验、载入、预处理、输出与评分；硬件为 Core Ultra 9 275HX，Python 3.12.3 / NumPy 2.5.3，缓存状态未控制，**参考 CPU 资格尚未确认**。

记录：[官方评分](runs/mlp_text_v1/test/score.json) · [完整命令、资源与分层比较](runs/mlp_text_v1/test/summary.json) · [冻结清单](runs/mlp_text_v1/test/freeze.json) · [冻结源码](runs/mlp_text_v1/test/source.tar)。分析复用旧线性的冻结预测，本轮未重跑其他 test 方法。

### linear_v1 冻结 test

2026-10-18，冻结 `linear_v1` 后，仅运行该线性方案的完整 test 预测和官方独立评分；未据 test 结果调参或重选模型。测试前保存代码、权重、配置的 SHA-256 和源码快照，测试后核对均未变化。

| 项目 | 结果 |
|---|---:|
| 官方 test accuracy | **375/467，80.29978586723769%** |
| 完整预测 + 独立评分外部总耗时 | **0.243 秒** |
| 实测总线程峰值 | **4**（编排 1 + 子进程 3） |
| 未压缩推理资产 | **28,771 字节**，约 28.10 KiB |
| 本机 CPU / 推理环境 | Core Ultra 9 275HX / Python 3.12.3、NumPy 2.5.3 |

耗时包含两个新进程的启动、导入、数据与资产哈希校验、加载、预处理、预测和评分；本机文件缓存状态未控制。**该成绩不是 Xeon Platinum 8457C 参考机测时，正式资格仍以参考机为准。**

记录：[官方评分](runs/linear_v1/test/score.json) · [耗时、线程与完整命令](runs/linear_v1/test/summary.json) · [冻结清单与检查结果](runs/linear_v1/test/freeze.json) · [冻结源码](runs/linear_v1/test/source.tar)。匹配权重位于 [checkpoint/](runs/linear_v1/checkpoint/)，冻结 ID 前缀为 `22c93832f59d`。

## 冻结结果复现

当前 M1 免训练复现（仍从 `code/` 执行，使用前述 3 线程环境设置；输出到新的目录）：

```bash
out=solution/runs/mlp_text_v1/test_reproduction
if mkdir "$out"; then
  time {
    .venv/bin/python predict.py \
      --method solution/group_ranker/submission_mlp.py \
      --checkpoint solution/runs/mlp_text_v1/checkpoint --split test \
      --output "$out/predictions.json" &&
    .venv/bin/python score_predictions.py --split test \
      --predictions "$out/predictions.json" --output "$out/score.json"
  }
fi
```

复现历史线性时，使用其冻结源码，将方法改为 `submission_linear.py`，checkpoint 改为 `solution/runs/linear_v1/checkpoint`，并使用新的输出目录；历史 JSON 保留原始完整命令。

仓库已包含 `linear_v1` 的匹配 checkpoint 和冻结记录；M1 及新实验产物目前仍在本地，默认由 Git 忽略。正式提交还需公开匹配源码和权重，完成参考机测时、至多 10 页报告及实际 AI 辅助与复用披露；保留数据许可。
